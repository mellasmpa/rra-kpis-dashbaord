import React, { useState } from "react";
import { ImFilesEmpty } from "react-icons/im";
import { IoReceiptOutline } from "react-icons/io5";
import { RiVisaFill } from "react-icons/ri";
import { BiSolidEdit } from "react-icons/bi";
import { FaUserCircle } from "react-icons/fa";
import { IoIosMenu } from "react-icons/io";
import logo from "./assets/images/logoc.png";

function App() {
  const [title, setTitle] = useState("EBM Usage Repoting");
  const [menuWidth, setMenuWidth] = useState(30);
  const [openMenu, setOpenMenu] = useState(false);
  return (
    <>
      <div className="w-full md:flex lg:flex xl:flex p-0 m-0">
        <div
          className={`bg-[#343a40] text-white ${
            openMenu ? `sm:block` : `hidden`
          } md:block lg:block xl:block w-[${menuWidth}px]  h-screen`}
        >
          <h1 className="font-bold py-3 px-3 border-b border-gray-600 flex items-center gap-2">
            <img src={logo} width={35} alt="logo" />
            {menuWidth === 300 ? "RRA KPIs DASHBOARD" : ""}
          </h1>
          <div>
            <ul>
              <li
                onClick={() => setTitle("EBM Usage and Reporting")}
                title="EBM"
                className="hover:bg-gray-500 px-3 py-2 border-b border-gray-600 flex items-center gap-3"
              >
                <IoReceiptOutline size={29} className="text-green-600" />{" "}
                {menuWidth === 300 ? "EBM" : ""}
              </li>
              <li
                onClick={() => setTitle("Filling Description")}
                className="hover:bg-gray-500 px-3 py-2 border-b border-gray-600 flex items-center gap-3"
              >
                <ImFilesEmpty size={29} className="text-green-600" />{" "}
                {menuWidth === 300 ? "Filing" : ""}
              </li>
              <li
                onClick={() => setTitle("payment status")}
                className="hover:bg-gray-500 px-3 py-2 border-b border-gray-600 flex items-center gap-3"
              >
                <RiVisaFill size={29} className="text-green-600" />{" "}
                {menuWidth === 300 ? "Payment" : ""}
              </li>
              <li
                onClick={() => setTitle("Registration and Deregistration")}
                className="hover:bg-gray-500 px-3 py-2 border-b border-gray-600 flex items-center gap-3"
              >
                <BiSolidEdit size={29} className="text-green-600" />{" "}
                {menuWidth === 300 ? "Registration" : ""}
              </li>
            </ul>
          </div>
        </div>
        <div className="min-h-screen w-full bg-slate-200">
          <div className="px-5 w-full bg-white shadow py-3 flex justify-between items-center">
            <div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setMenuWidth(menuWidth === 300 ? 30 : 300);
                    setOpenMenu(!openMenu);
                  }}
                >
                  <IoIosMenu size={30} />
                </button>
                <h1 className="text-2xl capitalize">{title}</h1>
              </div>
            </div>
            <div>
              <div>
                <FaUserCircle size={30} />
              </div>
            </div>
          </div>
          
          <div>
            {/* main content */}
          </div>
        </div>
      </div>
    </>
  );
}

export default App;
