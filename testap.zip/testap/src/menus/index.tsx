import React from 'react'

const MenuItems = () => {
  return (
    <div>MenuItems</div>
  )
}

export default MenuItems